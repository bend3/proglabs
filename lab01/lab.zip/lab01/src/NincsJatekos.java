
public class NincsJatekos extends Exception{
    public NincsJatekos() {
        super();
    }
}
